﻿namespace namelistsort
{
    internal interface INameProcessor
    {
        void SortList();
        void DisplaySortedNames();
    }

}
